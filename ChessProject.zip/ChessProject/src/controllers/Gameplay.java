package controllers;

import models.*;

public class Gameplay {

    private static Piece piece;
    private static Board board;
    private static Player player;

    public static void run() {

    }

    private static int mainMenu() {
        return 0;
    }

    private static void printBoard() {

    }
}
