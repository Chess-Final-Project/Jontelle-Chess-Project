package models;

public abstract class Piece {
    private boolean taken = false;
    private boolean White = false;

    public boolean isTaken() {
        return taken;
    }

    public void setTaken(boolean taken) {
        this.taken = taken;
    }

    public boolean isWhite() {
        return White;
    }

    public void setWhite(boolean white) {
        White = white;
    }

    public abstract boolean validMove(Board board, Position begin, Position end );


}
