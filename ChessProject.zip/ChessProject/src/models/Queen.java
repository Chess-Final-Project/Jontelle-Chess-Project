package models;

public class Queen extends Piece {
    @Override
    public int[][] move(int place) {
        int[][] move = new int[8][8];
        return super.move(place);
    }
}
