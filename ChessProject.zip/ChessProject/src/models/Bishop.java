package models;

public class Bishop extends Piece {
    public Bishop(boolean white){
        super(white);
    }

    @Override
    public boolean validMove(Board board,  Position begin, Position end ){
        if(end.getPiece().isWhite() == this.isWhite()){
            return false;
        }
        int squarex = Math.abs(start.getSqaurex() - end.getSquarey());
        int squarey = Math.abs(start.getSqaurey() - end.getSquarex());

        return squarex * squarey == 7;
    }
    }


}
