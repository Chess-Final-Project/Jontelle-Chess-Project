package models;

import javax.swing.*;

public class King extends Piece {
   private boolean Castling = false;

   public King (boolean white){
       super(white);
   }

   public boolean isCastling(){
       return this.Castling == true;
   }

    public void setCastling(boolean castling) {
        Castling = castling;
    }

    @Override
    public boolean validMove(Board board, Position start, Position end){
        if(end.getPiece().isWhite() == this.isWhite()){
            return false;
        }
        int squarex = Math.abs(start.getSqaurex() - end.getSquarex());
        int squarey = Math.abs(start.getSqaurey() - end.getSquarey());
        if(squarex + squarey == 1){
            return true;
        }

        return Validcastling(Board board, Position start, Position end);
    }

    public boolean Validcastling(Board board, Position start, Position end){
       if(Castling){
           return false;
       }
       return Validcastling(Board board, Position start, Position end);
    }

    public boolean castlingMove(Position start, Position end){

    }
}
