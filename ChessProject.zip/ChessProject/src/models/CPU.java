package models;

public class CPU extends Player {
    public void randMove(int[] place) {

    }
}
