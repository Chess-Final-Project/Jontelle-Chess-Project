package models;

public class Pawn extends Piece{

}
