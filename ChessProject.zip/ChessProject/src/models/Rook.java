package models;

public class Rook extends Piece {


}
