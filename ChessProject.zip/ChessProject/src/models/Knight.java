package models;

public class Knight extends Piece {
    public Knight(boolean white){
        super(white);
    }

    @Override
    public boolean validMove(Board board,  Position begin, Position end ){
        if(end.getPiece().isWhite() == this.isWhite()){
            return false;
        }
        int squarex = Math.abs(start.getSqaurex() - end.getSquarex());
        int squarey = Math.abs(start.getSqaurey() - end.getSquarey());

        return squarex * squarey == 2;
    }
}
