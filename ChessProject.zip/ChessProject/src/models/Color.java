package models;

public enum Color {
    BLACK,
    WHITE,
}
